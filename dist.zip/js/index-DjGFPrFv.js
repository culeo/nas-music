var x=(t,n,o)=>new Promise((i,s)=>{var e=r=>{try{l(o.next(r))}catch(a){s(a)}},c=r=>{try{l(o.throw(r))}catch(a){s(a)}},l=r=>r.done?i(r.value):Promise.resolve(r.value).then(e,c);l((o=o.apply(t,n)).next())});import{a4 as u,a5 as h,a6 as w,a7 as S,a8 as A,a9 as v,aa as z,ab as U,ac as V,ad as W,ae as G,af as F,ag as H,ah as K,ai as j,aj as D,ak as q,O as M,al as X,z as k,K as R,am as J,an as Y,J as Z,ao as Q,B as I,m as B}from"./bootstrap-D5ztrzrG.js";import{u as tt}from"./vxe-table-D3B7V4W_.js";import{a0 as $,h as m,X as y,a9 as et,L as T,as as ot,ab as nt,ac as it,ad as b,n as f,a6 as p,am as O,ak as N}from"../jse/index-index-DnBTUNTc.js";import{_ as rt}from"./page.vue_vue_type_script_setup_true_lang-Dzwjouu6.js";import"./use-preferences-DVRfRZgY.js";import"./loading-DsIN9HKB.js";const st=u("input-group",`
 display: inline-flex;
 width: 100%;
 flex-wrap: nowrap;
 vertical-align: bottom;
`,[h(">",[u("input",[h("&:not(:last-child)",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),h("&:not(:first-child)",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 margin-left: -1px!important;
 `)]),u("button",[h("&:not(:last-child)",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `,[w("state-border, border",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `)]),h("&:not(:first-child)",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `,[w("state-border, border",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `)])]),h("*",[h("&:not(:last-child)",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `,[h(">",[u("input",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),u("base-selection",[u("base-selection-label",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),u("base-selection-tags",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),w("box-shadow, border, state-border",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `)])])]),h("&:not(:first-child)",`
 margin-left: -1px!important;
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `,[h(">",[u("input",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `),u("base-selection",[u("base-selection-label",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `),u("base-selection-tags",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `),w("box-shadow, border, state-border",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `)])])])])])]),at={},lt=$({name:"InputGroup",props:at,setup(t){const{mergedClsPrefixRef:n}=S(t);return A("-input-group",st,n),{mergedClsPrefix:n}},render(){const{mergedClsPrefix:t}=this;return m("div",{class:`${t}-input-group`},this.$slots)}}),dt=u("icon",`
 height: 1em;
 width: 1em;
 line-height: 1em;
 text-align: center;
 display: inline-block;
 position: relative;
 fill: currentColor;
 transform: translateZ(0);
`,[v("color-transition",{transition:"color .3s var(--n-bezier)"}),v("depth",{color:"var(--n-color)"},[h("svg",{opacity:"var(--n-opacity)",transition:"opacity .3s var(--n-bezier)"})]),h("svg",{height:"1em",width:"1em"})]),ct=Object.assign(Object.assign({},z.props),{depth:[String,Number],size:[Number,String],color:String,component:[Object,Function]}),ut=$({_n_icon__:!0,name:"Icon",inheritAttrs:!1,props:ct,setup(t){const{mergedClsPrefixRef:n,inlineThemeDisabled:o}=S(t),i=z("Icon","-icon",dt,U,t,n),s=y(()=>{const{depth:c}=t,{common:{cubicBezierEaseInOut:l},self:r}=i.value;if(c!==void 0){const{color:a,[`opacity${c}Depth`]:d}=r;return{"--n-bezier":l,"--n-color":a,"--n-opacity":d}}return{"--n-bezier":l,"--n-color":"","--n-opacity":""}}),e=o?V("icon",y(()=>`${t.depth||"d"}`),s,t):void 0;return{mergedClsPrefix:n,mergedStyle:y(()=>{const{size:c,color:l}=t;return{fontSize:W(c),color:l}}),cssVars:o?void 0:s,themeClass:e==null?void 0:e.themeClass,onRender:e==null?void 0:e.onRender}},render(){var t;const{$parent:n,depth:o,mergedClsPrefix:i,component:s,onRender:e,themeClass:c}=this;return!((t=n==null?void 0:n.$options)===null||t===void 0)&&t._n_icon__&&G("icon","don't wrap `n-icon` inside `n-icon`"),e==null||e(),m("i",et(this.$attrs,{role:"img",class:[`${i}-icon`,c,{[`${i}-icon--depth`]:o,[`${i}-icon--color-transition`]:o!==void 0}],style:[this.cssVars,this.mergedStyle]}),s?m(s):this.$slots)}}),pt=h([h("@keyframes spin-rotate",`
 from {
 transform: rotate(0);
 }
 to {
 transform: rotate(360deg);
 }
 `),u("spin-container",`
 position: relative;
 `,[u("spin-body",`
 position: absolute;
 top: 50%;
 left: 50%;
 transform: translateX(-50%) translateY(-50%);
 `,[F()])]),u("spin-body",`
 display: inline-flex;
 align-items: center;
 justify-content: center;
 flex-direction: column;
 `),u("spin",`
 display: inline-flex;
 height: var(--n-size);
 width: var(--n-size);
 font-size: var(--n-size);
 color: var(--n-color);
 `,[v("rotate",`
 animation: spin-rotate 2s linear infinite;
 `)]),u("spin-description",`
 display: inline-block;
 font-size: var(--n-font-size);
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 margin-top: 8px;
 `),u("spin-content",`
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 pointer-events: all;
 `,[v("spinning",`
 user-select: none;
 -webkit-user-select: none;
 pointer-events: none;
 opacity: var(--n-opacity-spinning);
 `)])]),mt={small:20,medium:18,large:16},ft=Object.assign(Object.assign({},z.props),{contentClass:String,contentStyle:[Object,String],description:String,stroke:String,size:{type:[String,Number],default:"medium"},show:{type:Boolean,default:!0},strokeWidth:Number,rotate:{type:Boolean,default:!0},spinning:{type:Boolean,validator:()=>!0,default:void 0},delay:Number}),ht=$({name:"Spin",props:ft,setup(t){const{mergedClsPrefixRef:n,inlineThemeDisabled:o}=S(t),i=z("Spin","-spin",pt,H,t,n),s=y(()=>{const{size:r}=t,{common:{cubicBezierEaseInOut:a},self:d}=i.value,{opacitySpinning:g,color:C,textColor:_}=d,P=typeof r=="number"?K(r):d[j("size",r)];return{"--n-bezier":a,"--n-opacity-spinning":g,"--n-size":P,"--n-color":C,"--n-text-color":_}}),e=o?V("spin",y(()=>{const{size:r}=t;return typeof r=="number"?String(r):r[0]}),s,t):void 0,c=D(t,["spinning","show"]),l=T(!1);return ot(r=>{let a;if(c.value){const{delay:d}=t;if(d){a=window.setTimeout(()=>{l.value=!0},d),r(()=>{clearTimeout(a)});return}}l.value=c.value}),{mergedClsPrefix:n,active:l,mergedStrokeWidth:y(()=>{const{strokeWidth:r}=t;if(r!==void 0)return r;const{size:a}=t;return mt[typeof a=="number"?"medium":a]}),cssVars:o?void 0:s,themeClass:e==null?void 0:e.themeClass,onRender:e==null?void 0:e.onRender}},render(){var t,n;const{$slots:o,mergedClsPrefix:i,description:s}=this,e=o.icon&&this.rotate,c=(s||o.description)&&m("div",{class:`${i}-spin-description`},s||((t=o.description)===null||t===void 0?void 0:t.call(o))),l=o.icon?m("div",{class:[`${i}-spin-body`,this.themeClass]},m("div",{class:[`${i}-spin`,e&&`${i}-spin--rotate`],style:o.default?"":this.cssVars},o.icon()),c):m("div",{class:[`${i}-spin-body`,this.themeClass]},m(q,{clsPrefix:i,style:o.default?"":this.cssVars,stroke:this.stroke,"stroke-width":this.mergedStrokeWidth,class:`${i}-spin`}),c);return(n=this.onRender)===null||n===void 0||n.call(this),o.default?m("div",{class:[`${i}-spin-container`,this.themeClass],style:this.cssVars},m("div",{class:[`${i}-spin-content`,this.active&&`${i}-spin-content--spinning`,this.contentClass],style:this.contentStyle},o),m(M,{name:"fade-in-transition"},{default:()=>this.active?l:null})):l}}),bt=u("text",`
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
`,[v("strong",`
 font-weight: var(--n-font-weight-strong);
 `),v("italic",{fontStyle:"italic"}),v("underline",{textDecoration:"underline"}),v("code",`
 line-height: 1.4;
 display: inline-block;
 font-family: var(--n-font-famliy-mono);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 box-sizing: border-box;
 padding: .05em .35em 0 .35em;
 border-radius: var(--n-code-border-radius);
 font-size: .9em;
 color: var(--n-code-text-color);
 background-color: var(--n-code-color);
 border: var(--n-code-border);
 `)]),gt=Object.assign(Object.assign({},z.props),{code:Boolean,type:{type:String,default:"default"},delete:Boolean,strong:Boolean,italic:Boolean,underline:Boolean,depth:[String,Number],tag:String,as:{type:String,validator:()=>!0,default:void 0}}),vt=$({name:"Text",props:gt,setup(t){const{mergedClsPrefixRef:n,inlineThemeDisabled:o}=S(t),i=z("Typography","-text",bt,X,t,n),s=y(()=>{const{depth:c,type:l}=t,r=l==="default"?c===void 0?"textColor":`textColor${c}Depth`:j("textColor",l),{common:{fontWeightStrong:a,fontFamilyMono:d,cubicBezierEaseInOut:g},self:{codeTextColor:C,codeBorderRadius:_,codeColor:P,codeBorder:E,[r]:L}}=i.value;return{"--n-bezier":g,"--n-text-color":L,"--n-font-weight-strong":a,"--n-font-famliy-mono":d,"--n-code-border-radius":_,"--n-code-text-color":C,"--n-code-color":P,"--n-code-border":E}}),e=o?V("text",y(()=>`${t.type[0]}${t.depth||""}`),s,t):void 0;return{mergedClsPrefix:n,compitableTag:D(t,["as","tag"]),cssVars:o?void 0:s,themeClass:e==null?void 0:e.themeClass,onRender:e==null?void 0:e.onRender}},render(){var t,n,o;const{mergedClsPrefix:i}=this;(t=this.onRender)===null||t===void 0||t.call(this);const s=[`${i}-text`,this.themeClass,{[`${i}-text--code`]:this.code,[`${i}-text--delete`]:this.delete,[`${i}-text--strong`]:this.strong,[`${i}-text--italic`]:this.italic,[`${i}-text--underline`]:this.underline}],e=(o=(n=this.$slots).default)===null||o===void 0?void 0:o.call(n);return this.code?m("code",{class:s,style:this.cssVars},this.delete?m("del",null,e):e):this.delete?m("del",{class:s,style:this.cssVars},e):m(this.compitableTag||"span",{class:s,style:this.cssVars},e)}});function yt(){return x(this,null,function*(){return k.get("/plugin/list")})}function xt(t){return x(this,null,function*(){return k.post("/plugin/batch/import",{url:t})})}function Ct(t){return x(this,null,function*(){const n=new FormData;return n.append("file",t),k.post("/plugin/upload",n,{headers:{"Content-Type":"multipart/form-data"}})})}function zt(t){return x(this,null,function*(){return k.delete(`/plugin/${t}`)})}const $t={style:{"margin-bottom":"12px"}},_t={class:"vp-raw w-full"},Tt=$({__name:"index",setup(t){const n=T(!1),o=T(""),i={columns:[{align:"left",title:"名称",field:"name"},{slots:{default:"action"},title:"操作",width:100}],stripe:!0,keepSource:!0,proxyConfig:{ajax:{query:a=>x(this,[a],function*({}){return yield yt()})}},toolbarConfig:{custom:!1,export:!1,refresh:!1,zoom:!1},pagerConfig:{enabled:!1}},[s,e]=tt({gridOptions:i}),c=a=>x(this,null,function*(){const{file:d,onFinish:g,onError:C}=a;try{yield Ct(d.file),B.success("上传成功"),e.reload(),g()}catch(_){C()}});function l(){n.value=!0,console.log("pluginsUrl",o.value),xt(o.value).then(()=>{B.success("导入成功"),e.reload()}).finally(()=>{n.value=!1})}function r(a){console.log("row",a),zt(a.name).then(()=>{B.success("删除成功"),e.reload()})}return(a,d)=>(nt(),it(p(rt),{description:"管理第三方插件",title:"插件管理",class:"my-5"},{default:b(()=>[f(p(R),{title:"本地文件导入",size:"small"},{default:b(()=>[f(p(J),{multiple:"","directory-dnd":"","custom-request":c,max:5},{default:b(()=>[f(p(Y),null,{default:b(()=>[O("div",$t,[f(p(ut),{size:"58",depth:3},{default:b(()=>[f(p(Z),{class:"text-2xl",icon:"lucide:upload"})]),_:1})]),f(p(vt),{style:{"font-size":"16px"}},{default:b(()=>d[1]||(d[1]=[N(" 点击或者拖动文件到该区域来上传 ")])),_:1})]),_:1})]),_:1})]),_:1}),f(p(R),{title:"在线文件导入",size:"small",class:"my-5"},{default:b(()=>[f(p(ht),{show:n.value},{default:b(()=>[f(p(lt),null,{default:b(()=>[f(p(Q),{class:"w-40",value:o.value,"onUpdate:value":d[0]||(d[0]=g=>o.value=g),placeholder:"请输入插件地址"},null,8,["value"]),f(p(I),{type:"primary",onClick:l},{default:b(()=>d[2]||(d[2]=[N(" 导入 ")])),_:1})]),_:1})]),_:1},8,["show"])]),_:1}),f(p(R),{title:"已安装插件",size:"small",class:"my-5"},{default:b(()=>[O("div",_t,[f(p(s),null,{action:b(({row:g})=>[f(p(I),{secondary:"",type:"error",onClick:C=>r(g)},{default:b(()=>d[3]||(d[3]=[N("删除")])),_:2},1032,["onClick"])]),_:1})])]),_:1})]),_:1}))}});export{Tt as default};
